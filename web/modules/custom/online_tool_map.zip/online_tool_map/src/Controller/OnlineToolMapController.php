<?php

namespace Drupal\online_tool_map\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller.
 */
class OnlineToolMapController extends ControllerBase {

  /**
   * Returns a render-able array for a test page.
   */
  public function content() {
    $build = [
        '#type' => 'page',
        'content' => [
          'system_main' => [
          ],
          'another_block' => [
          ],
          '#sorted' => TRUE,
          '#markup' => '<h1>testing</h1>',
        ],
        // '#theme' => 'online_tool_map', // Replace with your template name.
        
        // '#variable_name' => null,   // Pass variables to the template if needed.
      ];
      return $build;
  }

}